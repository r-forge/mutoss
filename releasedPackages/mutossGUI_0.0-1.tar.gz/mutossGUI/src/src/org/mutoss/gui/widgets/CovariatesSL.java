package org.mutoss.gui.widgets;

import java.util.List;

import org.af.jhlir.call.RLegalName;


public class CovariatesSL extends VarSelectSL{
    public CovariatesSL(List<RLegalName> left) {
        super(left);
    }
}
