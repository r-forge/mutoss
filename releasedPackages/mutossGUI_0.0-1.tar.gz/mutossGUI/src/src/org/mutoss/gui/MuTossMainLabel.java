package org.mutoss.gui;

import javax.swing.JLabel;

public class MuTossMainLabel extends JLabel {

	public MuTossMainLabel(String label) {
		super(label);
	}
	
	public MuTossMainLabel() {
		super("n/a");
	}
	
	
}
