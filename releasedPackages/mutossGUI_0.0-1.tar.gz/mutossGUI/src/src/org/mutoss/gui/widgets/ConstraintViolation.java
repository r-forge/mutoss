package org.mutoss.gui.widgets;


public class ConstraintViolation extends Exception{
    public ConstraintViolation(String message) {
        super(message);
    }
}
