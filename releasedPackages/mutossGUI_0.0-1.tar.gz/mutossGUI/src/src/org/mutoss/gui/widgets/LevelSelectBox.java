package org.mutoss.gui.widgets;

import org.af.commons.widgets.lists.MyJComboBox;

public class LevelSelectBox extends MyJComboBox<String>{

}
