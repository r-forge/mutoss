package org.mutoss.gui.parameterwidgets;

public interface ParameterWidget {
	
	public Object getParameter();

}
