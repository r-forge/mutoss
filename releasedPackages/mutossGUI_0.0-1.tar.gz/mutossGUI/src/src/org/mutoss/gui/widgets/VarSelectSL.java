package org.mutoss.gui.widgets;

import java.util.List;

import org.af.commons.widgets.lists.SplitList;
import org.af.jhlir.call.RLegalName;


public class VarSelectSL extends SplitList<RLegalName> {
    public VarSelectSL(List<RLegalName> left) {
        super(left);
    }
}
